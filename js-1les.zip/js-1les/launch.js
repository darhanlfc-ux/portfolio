// // ZadanieN1

// var summa = 1000
// var discount = 0;

// if (summa < 100) {
//     discount = 0;}

// if (summa < 500) {
//         discount = 5;
//     } 

// if (summa < 1000) {
//     discount = 10;
// }
 
//  else {
//     discount = 15;
//         }

// var finalSumma = summa - summa * discount / 100;

// console.log("Скидка: " + discount + "%");
// console.log("Итоговая сумма: $" + finalSumma);

// ZadanieN2

var str = "10";   // string
var num = 5;      // number

// undefined
var x;
console.log(x);

// false
console.log(num > 10);

// true
console.log(num < 10);

// NaN
console.log(Number("abc"));

// number
console.log(typeof num);

// string
console.log(typeof str);